package com.example.opreaciones;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText txt1,txt2;
    Button bttotal;
    TextView txtvtotal,txtres;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt1= findViewById(R.id.txt1);
        txt2= findViewById(R.id.txt2);
        txtvtotal= findViewById(R.id.txttotal);
        txtres=findViewById(R.id.txtres);

    }

    public void sumar(View view) {
        float v1= Float.parseFloat(txt1.getText().toString());
        float v2= Float.parseFloat(txt2.getText().toString());
        float total= v1+v2;
        txtvtotal.setText(R.string.su);
        String to=String.valueOf(total);
        txtres.setText(to);

    }

    public void restar(View view) {
        float v1= Float.parseFloat(txt1.getText().toString());
        float v2= Float.parseFloat(txt2.getText().toString());
        float total= v1-v2;
        txtvtotal.setText(R.string.re);
        String to=String.valueOf(total);
        txtres.setText(to);
       // txtvtotal.setText("La resta es: "+ total);
    }

    public void multiplicar(View view) {
        float v1= Float.parseFloat(txt1.getText().toString());
        float v2= Float.parseFloat(txt2.getText().toString());
        float total= v1*v2;
        //txtvtotal.setText("La multiplicación es: "+ total);
        txtvtotal.setText(R.string.mu);
        String to=String.valueOf(total);
        txtres.setText(to);

    }

    public void dividir(View view) {
        float v1= Float.parseFloat(txt1.getText().toString());
        float v2= Float.parseFloat(txt2.getText().toString());
        float total= v1/v2;
        //txtvtotal.setText("La división es: "+ total);
        txtvtotal.setText(R.string.di);
        String to=String.valueOf(total);
        txtres.setText(to);

    }
}